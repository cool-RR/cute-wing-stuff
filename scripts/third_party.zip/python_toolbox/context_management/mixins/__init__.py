# Copyright 2009-2017 Ram Rachum.
# This program is distributed under the MIT license.

'''Defines mixins for `ContextManager`.'''


from .decorating_context_manager_mixin import _DecoratingContextManagerMixin