# Copyright 2009-2015 Ram Rachum.
# This program is distributed under the MIT license.

'''Defines base classes for `ContextManager`.'''


from .decorating_context_manager import DecoratingContextManager