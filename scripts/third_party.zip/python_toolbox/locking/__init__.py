# Copyright 2009-2014 Ram Rachum.
# This program is distributed under the MIT license.

'''
This package defines a class `ReadWriteLock` in the module `read_write_lock`.

See that class's documentation for more details.
'''

from .read_write_lock import ReadWriteLock
