# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
Defines the `Knob` class.

See its documentation for more info.
'''

from .knob import Knob