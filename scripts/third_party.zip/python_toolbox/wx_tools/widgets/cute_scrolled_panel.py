# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
This module defines the `` class.

See its documentation for more information.
'''

import wx.lib.scrolledpanel

from python_toolbox.wx_tools.widgets.cute_panel import CutePanel


class CuteScrolledPanel(wx.lib.scrolledpanel.ScrolledPanel, CutePanel):
    '''
    
    '''
    