# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
Defines the `CuteWindow` class.

See its documentation for more information.
'''

from .cute_window import CuteWindow