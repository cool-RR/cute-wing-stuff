# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

import wx

from python_toolbox.wx_tools.widgets.cute_window import CuteWindow


class CuteControl(wx.Control, CuteWindow):
    pass