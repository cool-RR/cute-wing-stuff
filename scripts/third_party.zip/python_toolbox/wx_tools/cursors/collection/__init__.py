# Copyright 2009-2017 Ram Rachum.
# This program is distributed under the MIT license.

'''A collection of cursors.'''

from .collection import get_open_grab, get_closed_grab