# Copyright 2009-2015 Ram Rachum.
# This program is distributed under the MIT license.

'''Defines various cursor-related tools.'''

from . import collection
from .cursor_changer import CursorChanger